# 다른 컴퓨터에서 작업 이어가기

## 클라우드에서 이어가기
사용자는 파일 이동 없이 Codex Cloud 환경에서 계속 작업하기를 요청했습니다. ZIP 전달 방식은 최종 목표가 아닙니다.
기존 사이트 소스는 Sites의 비공개 Git 저장소에 있습니다. Codex Cloud 환경은 GitHub/GitLab 저장소 연결이 필요합니다. 클라우드에서 실행 가능한 전체 웹 소스와 인수인계 정보를 이 저장소에 준비했습니다.
현재 준비만 완료했으며 GitHub로 이전하거나 Codex Cloud 환경을 생성한 것은 아닙니다. 브라우저의 Codex Cloud 로그인이 필요합니다. 연결된 GitHub 계정은 yjyj41이며 확인 당시 접근 가능 저장소는 다른 프로젝트인 bullet-journal뿐입니다. 기존의 무관한 저장소를 덮어쓰지 마세요. 별도의 비공개 london-isometric-atlas 저장소를 만들고 접근 권한을 확인한 뒤 이전하는 방향입니다.
설정 후 클라우드 작업 시작 문구:
> AGENTS.md와 HANDOFF.md를 읽고 런던 3D 지도 작업을 이어줘. node serve.cjs로 실행해 현재 상태를 확인하고, 실제 미터 스케일·고정 아이소메트릭·Rhino 6/7 호환을 유지해줘. 기존 .openai/hosting.json의 Sites 프로젝트를 재사용해줘.
브라우저 IndexedDB에만 저장한 개인 수정 모델은 소스 저장소에 없습니다. 원래 .3dm을 클라우드 작업에 별도로 제공해야 합니다.

## 현재 구현 (2026-09-22)
- 중앙 런던 약 4.2 × 3.0 km, 실제 OSM 윤곽 기반 16,741개 매스.
- 랜드마크 12곳. St Paul's, Shard, Gherkin, Tower Bridge, Tate Modern, Millennium Bridge, Barbican, Lloyd's, Westminster, Abbey, British Museum, Tower of London.
- Three.js 0.180, 직교 투영, 방위각 45°, 고도각 35.264°, 회전 잠금.
- X east / Y north / Z up의 미터 좌표. Three에서는 X east / Y up / Z south로 변환.
- AEQD 원점 위도 51.51, 경도 -0.106. 개별 Rhino 파일은 landmark.anchor 기준 로컬 좌표, 전체 도시는 공통 원점.
- Rhino 다운로드는 6 형식(archive header 60). Rhino 7에서도 사용. 파일은 메시이며 NURBS/BIM 아님.
- .3dm 재불러오기, 단위 인식, 전체 도시/개별 건물 교체, IndexedDB 유지, 원본 복원.
- 지형 평면. 높이 출처: OSM height 3,994 / 층수×3.2m 6,585 / 12m 가정 6,162. 지붕과 일부 랜드마크 형태는 근사. 측량용 모델 아님.

## 파일 구조와 실행
- dist/index.html, style.css, app.js: UI와 모델 불러오기.
- dist/mass-scene.js: Three 렌더러, 고정 카메라, 도시 배치, 모델 교체.
- dist/geometry.js: 동일 매스를 브라우저와 Rhino에 생성하는 공통 기하.
- dist/storage.js: 기기별 IndexedDB 저장소.
- dist/assets/city.json: 현재 매스 데이터, 원점, 랜드마크, OSM 출처. 원시 OSM 없이 기존 사이트 편집 가능.
- dist/assets/rhino/: 도시 ZIP과 개별 .3dm. 기존 다운로드 경로도 Rhino 6 파일로 유지.
- dist/vendor/: 필요한 JS/WASM 라이브러리 포함. 기본 실행에는 외부 패키지 설치 불필요.
- .openai/hosting.json: 기존 사이트 식별 정보. 인증정보 아님.
- node serve.cjs → http://127.0.0.1:4173 (Node.js 필요).

## 매스 다시 생성하기 (필요한 경우만)
프로젝트 루트에서 Python 환경에 `pip install -r tools/requirements.txt` 실행.
`node tools/export-meshes.mjs` 다음 `python tools/export-rhino.py` 실행.
rhino3dm 라이브러리 버전 8.35여도 출력 파일 버전은 반드시 Write(..., 6).
OSM 재수집은 `python tools/fetch-osm.py`, 이후 `python tools/build-city.py`. 이 작업은 인터넷과 시간이 필요하며 최신 OSM이므로 현재 스냅샷과 결과가 달라질 수 있음. 일반 UI 변경에는 실행 불필요.

## 배포와 충돌 방지
기존 사이트 ID: appgprj_6ab0f6c9e0f4819199adfc6864b7515d
현재 접근 범위: 소유자 전용. 사용자가 요청하지 않으면 공개로 변경하지 않음.
Sites 플러그인을 이용하고, 같은 소유자 계정/워크스페이스에서 기존 사이트를 열 것. 다른 PC의 인증·도구 사용 가능 여부는 그 PC에서 확인해야 함.
Sites source credential을 새로 발급받아 반환된 Git 저장소를 복제하면 최신 소스와 이력이 복구됨. 인증정보를 소스에 저장하지 말 것. 최신 원격 변경을 먼저 확인하고 강제 덮어쓰지 말 것.
이 PC에서는 bash가 없어 공식 로컬 패키징 도구가 실행되지 않아 push → save_site_version(원격 빌드) → deploy_private_site_version 경로 사용. 다른 환경에서 공식 패키징 가능하면 정상 archive 배포 사용.
클라우드 작업과 로컬 작업에서 동시에 배포하지 말 것.

## 확인한 기능과 미완료 범위
로컬 데스크톱/모바일 렌더링, St Paul's .3dm 원본 크기 왕복, 브라우저 새로고침 유지, 전체 도시 16,741개 메시 인식·교체·복원 확인. Rhino 6 파일은 헤더/객체명/메시 개수/미터 단위 검사 완료. 실제 Rhino 6 데스크톱 앱 실행 검증은 하지 않음.
런던 전체 확장은 사용자와 가능성만 논의했으며 아직 구현 요청·착수하지 않음. 향후 타일별 로딩/LOD가 필요. 서버 모델 동기화·공동 편집·Codex Cloud 실행 환경은 미구현.

OSM 데이터와 파생 매스는 ODbL 1.0. https://www.openstreetmap.org/copyright
