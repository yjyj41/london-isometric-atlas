# London Field Atlas

Read HANDOFF.md before continuing. This is an existing private Sites website. Preserve the project_id in .openai/hosting.json and update that Site; do not create a replacement. Use the available Sites skill and authenticated connector for publishing. Never store credentials in files or source archives.

The user's priorities are metric real 3D mass geometry, a fixed orthographic isometric camera, and Rhino 6/7-compatible edit-and-reimport workflows. Preserve metre units and coordinate origins. Keep OSM attribution and distinguish inferred heights from recorded values.

Run locally with `node serve.cjs`; no npm install or frontend build is needed. Source is dist/.

The intended continuation environment is Codex Cloud backed by a dedicated private GitHub repository. Check the current remote branch before publishing from a different PC, and merge newer work rather than overwriting it. Use fresh repo-scoped credentials through Sites; never force-push another machine's work.
